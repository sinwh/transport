﻿

using kcp2k;
using KCPTest.Test;
using System.Text;

Mode mode = Mode.None;

if (args.Length < 1)
{
    Console.WriteLine("Invalid arguments");
    return;
}

mode = (Mode)int.Parse(args[0]);

// mode serverport
if (mode == Mode.Server)
{
    if (args.Length < 2)
    {
        Console.WriteLine("Invalid arguments");
        return;
    }
    Log.Configure(Path.Combine(Environment.CurrentDirectory, "logs", "server.log"));
    Server server = new Server();
    server.Start(ushort.Parse(args[1]));
    return;
}

// mode serverip serverport
if (mode == Mode.Client)
{
    if (args.Length < 4)
    {
        Console.WriteLine("Invalid arguments");
        return;
    }
    string id = args[3];
    Log.Configure(Path.Combine(Environment.CurrentDirectory, "logs", $"client-{id}.log"));
    Client client = new Client(id);
    client.Connect(args[1], ushort.Parse(args[2]));

    if (args.Length == 5)
    {
        Thread.Sleep(int.MaxValue);
    }
    else
    {
        while (true)
        {
            Console.WriteLine("[1]-begin send [0]-exit");
            string line = Console.ReadLine();
            line = line.Trim();
            if ("1".Equals(line))
            {
                client.autoSend = true;
            }
            else if ("0".Equals(line))
            {
                break;
            }
        }
    }
}