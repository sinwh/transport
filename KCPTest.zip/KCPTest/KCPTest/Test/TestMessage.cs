﻿namespace KCPTest.Test
{
    public class TestMessage
    {
        public string id;
        public string type;
        public string data;
    }
}
