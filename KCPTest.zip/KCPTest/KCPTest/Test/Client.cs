﻿using kcp2k;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Text;

namespace KCPTest.Test
{
    public class Client
    {
        private const string DATA = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        //private const string DATA = "{\"head\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"leftHand\":{\"f00\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f01\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f02\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f10\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f11\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f12\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f13\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f20\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f21\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f22\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f23\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f30\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f31\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f32\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f33\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f40\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f41\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f42\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f43\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"}},\"rightHand\":{\"f00\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f01\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f02\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f10\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f11\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f12\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f13\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f20\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f21\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f22\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f23\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f30\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f31\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f32\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f33\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f40\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f41\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f42\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"},\"f43\":{\"px\":\"999.9999\",\"py\":\"999.9999\",\"pz\":\"999.9999\",\"rx\":\"0.99999\",\"ry\":\"0.99999\",\"rz\":\"0.99999\"}}}";

        private string id;
        private KcpClient client;
        public bool autoSend = false;
        private int index = 0;

        private BlockingCollection<ArraySegment<byte>> recvQueue = new BlockingCollection<ArraySegment<byte>>();
        private ConcurrentDictionary<string, long> timeCache = new ConcurrentDictionary<string, long>();

        public Client(string id)
        {
            this.id = id;
            client = new KcpClient(OnConnected, OnData, OnDisconnected, OnError, new KcpConfig() { SendWindowSize = 1024, ReceiveWindowSize = 1024 });
        }

        public void Connect(string address, ushort port)
        {
            client.Connect(address, port);

            //Task.Run(() =>
            //{
            //    while (true)
            //    {
            //        ProcessMessage();
            //    }
            //});

            Task.Run(() =>
            {
                while (true)
                {
                    if (autoSend)
                    {
                        SendMessage();
                    }
                    client.Tick();
                    Thread.Sleep(10);
                }
            });
        }

        private void OnConnected()
        {
            Log.Info($"OnConnected");
            autoSend = true;
        }

        private void OnData(ArraySegment<byte> data, KcpChannel channel)
        {
            //recvQueue.Add(data);
            ProcessMessage(data);
        }

        private void OnDisconnected()
        {
            Log.Info($"OnDisconnected");
        }

        private void OnError(ErrorCode code, string message)
        {
            Log.Error($"OnError {code} {message}");
        }

        private void ProcessMessage(ArraySegment<byte> data)
        {
            try
            {
                TestMessage message = JsonConvert.DeserializeObject<TestMessage>(Encoding.UTF8.GetString(data));
                if ("2".Equals(message.type))
                {
                    if (timeCache.TryGetValue(message.id, out long time))
                    {
                        timeCache.Remove(message.id, out time);
                        Log.Info($"RTT: {message.id} {DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - time} {timeCache.Count}");
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
        }

        private void SendMessage()
        {
            string messageId = id + "_" + index;
            TestMessage message = new TestMessage()
            {
                id = messageId,
                type = "1",
                data = DATA
            };
            timeCache.TryAdd(messageId, DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
            index++;
            client.Send(new ArraySegment<byte>(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message))), KcpChannel.Reliable);
        }

        private void SendAck(string messageId)
        {
            TestMessage message = new TestMessage()
            {
                id = messageId,
                type = "2"
            };
            client.Send(new ArraySegment<byte>(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message))), KcpChannel.Reliable);
        }
    }
}
