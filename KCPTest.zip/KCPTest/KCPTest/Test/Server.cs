﻿
using kcp2k;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;

namespace KCPTest.Test
{
    public class Server
    {
        class TransData
        {
            public int id;
            public byte[] data;
        }

        private KcpServer kcpServer;
        private BlockingCollection<TransData> recvQueue = new BlockingCollection<TransData>();
        private BlockingCollection<TransData> sendQueue = new BlockingCollection<TransData>();

        private Stopwatch stopwatch = new Stopwatch();

        public Server()
        {
            kcpServer = new KcpServer(OnConnected, OnData, OnDisconnected, OnError, new KcpConfig() { SendWindowSize = 1024, ReceiveWindowSize = 1024 });
        }

        public void Start(ushort port)
        {
            kcpServer.Start(port);
            Task.Run(ProcessMessage);
            Task.Run(ProcessMessage);
            Task.Run(ProcessMessage);
            Task.Run(ProcessMessage);
            Task.Run(ProcessMessage);
            Task.Run(ProcessMessage);
            Task.Run(ProcessMessage);
            Task.Run(ProcessMessage);
            stopwatch.Start();
            while (true)
            {
                long begin = stopwatch.ElapsedMilliseconds;
                while (sendQueue.TryTake(out TransData transData))
                {
                    kcpServer.Send(transData.id, transData.data, KcpChannel.Reliable);
                    if (stopwatch.ElapsedMilliseconds - begin > 10)
                    {
                        break;
                    }
                }
                kcpServer.Tick();
                long cost = stopwatch.ElapsedMilliseconds - begin;
                if (cost > 0)
                {
                    Thread.Sleep((int)cost);
                }

            }
        }

        private void OnConnected(int id)
        {
            Log.Info($"OnConnected {id}");
        }

        private void OnData(int id, ArraySegment<byte> data, KcpChannel channel)
        {
            recvQueue.Add(new TransData() { id = id, data = data.ToArray() });

        }

        private void ProcessMessage()
        {
            while (true)
            {
                try
                {
                    TransData data = recvQueue.Take();
                    TestMessage testMessage = JsonConvert.DeserializeObject<TestMessage>(Encoding.UTF8.GetString(data.data));
                    if ("1".Equals(testMessage.type))
                    {
                        SendAck(data.id, testMessage.id, testMessage.data);
                    }
                }
                catch (Exception e)
                {
                    Log.Error(e);
                }
            }
        }

        private void OnDisconnected(int id)
        {
            Log.Info($"OnDisconnected {id}");
        }

        private void OnError(int id, ErrorCode code, string message)
        {
            Log.Error($"OnError {id} {code} {message}");
        }

        private void SendAck(int connectionId, string messageId, string messageData)
        {
            TestMessage message = new TestMessage()
            {
                id = messageId,
                type = "2",
                data = messageData
            };
            sendQueue.Add(new TransData() { id = connectionId, data = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message)) });
        }
    }
}
