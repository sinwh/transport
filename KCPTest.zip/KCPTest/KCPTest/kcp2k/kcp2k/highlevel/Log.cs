﻿namespace kcp2k
{
    public static class Log
    {


        public static void Configure(string output)
        {
            var configuration = new NLog.Config.LoggingConfiguration();
            string fileLayout = "${longdate} [${level:uppercase=true}][${logger}][${callsite:className=true:fileName=false:includeSourcePath=false:methodName=true:skipFrames=1}(${callsite-linenumber:skipFrames=1})]: ${message:withexception=true}";
            var logfile = new NLog.Targets.FileTarget("logfile") { FileName = output };
            logfile.Layout = fileLayout;
            configuration.AddRule(NLog.LogLevel.Debug, NLog.LogLevel.Fatal, logfile);
            NLog.LogManager.Configuration = configuration;
        }

        public static void Info(string message)
        {
            NLog.LogManager.GetLogger("[KCPTest]").Info(message);
        }

        public static void Warning(string message)
        {
            NLog.LogManager.GetLogger("[KCPTest]").Warn(message);
        }

        public static void Error(string message)
        {
            NLog.LogManager.GetLogger("[KCPTest]").Error(message);
        }

        public static void Error(Exception e)
        {
            NLog.LogManager.GetLogger("[KCPTest]").Error(e);
        }
    }
}
